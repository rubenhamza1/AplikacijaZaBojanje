﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BojanjeAplikacija
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private enum Oblik
        {
            Crta, Elipsa, Pravokutnik
        }
        private Oblik odabraniOblik;

        private enum Pisalo
        {
            Kist, Olovka
        }
        private Pisalo odabranoPisalo;

        public MainWindow()
        {
            InitializeComponent();
        }

        Point pocetak;
        Point kraj;
        Point tocka = new Point();

        private void canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pocetak = e.GetPosition(this);
        }

        private void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            switch (odabraniOblik)
            {
                case Oblik.Crta:
                    nacrtajCrtu();
                    break;
                case Oblik.Elipsa:
                    nacrtajElipsu();
                    break;
                case Oblik.Pravokutnik:
                    nacrtajPravokutnik();
                    break;
                default:
                    return;
            }
            switch (odabranoPisalo)
            {
                case Pisalo.Olovka:
                    Olovka();
                    break;
            }
        }
        private void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Line line = new Line();

                line.Stroke = SystemColors.WindowFrameBrush;
                line.X1 = tocka.X;
                line.Y1 = tocka.Y;
                line.X2 = e.GetPosition(this).X;
                line.Y2 = e.GetPosition(this).Y;

                tocka = e.GetPosition(this);

                canvas.Children.Add(line);
            }
        }

        private void nacrtajCrtu()
        {
            Line novaCrta = new Line()
            {
                Stroke = Brushes.Black,
                StrokeThickness = 4,
                X1 = pocetak.X,
                Y1 = pocetak.Y - 50,
                X2 = kraj.X,
                Y2 = kraj.Y - 50
            };
            canvas.Children.Add(novaCrta);
        }
        private void nacrtajElipsu()
        {
            Ellipse novaElipsa = new Ellipse()
            {
                Stretch = Stretch.Fill,
                Stroke = Brushes.Black,
                StrokeThickness = 4,
                Height = 10,
                Width = 10
            };
            if (kraj.X >= pocetak.X)
            {
                novaElipsa.SetValue(Canvas.LeftProperty, pocetak.X);
                novaElipsa.Width = kraj.X - pocetak.X;
            }
            else
            {
                novaElipsa.SetValue(Canvas.LeftProperty, kraj.X);
                novaElipsa.Width = pocetak.X - kraj.X;
            }
            if (kraj.Y >= pocetak.Y)
            {
                novaElipsa.SetValue(Canvas.TopProperty, pocetak.Y - 50);
                novaElipsa.Height = kraj.Y - pocetak.Y;
            }
            else
            {
                novaElipsa.SetValue(Canvas.TopProperty, kraj.Y - 50);
                novaElipsa.Height = pocetak.Y - kraj.Y;
            }
            canvas.Children.Add(novaElipsa);
        }
        private void nacrtajPravokutnik()
        {
            Rectangle noviPravokutnik = new Rectangle()
            {
                Stroke = Brushes.Black,
                StrokeThickness = 4,
                Height = 10,
                Width = 10
            };
            if (kraj.X >= pocetak.X)
            {
                noviPravokutnik.SetValue(Canvas.LeftProperty, pocetak.X);
                noviPravokutnik.Width = kraj.X - pocetak.X;
            }
            else
            {
                noviPravokutnik.SetValue(Canvas.LeftProperty, kraj.X);
                noviPravokutnik.Width = pocetak.X - kraj.X;
            }
            if (kraj.Y >= pocetak.Y)
            {
                noviPravokutnik.SetValue(Canvas.TopProperty, pocetak.Y - 50);
                noviPravokutnik.Height = kraj.Y - pocetak.Y;
            }
            else
            {
                noviPravokutnik.SetValue(Canvas.TopProperty, kraj.Y - 50);
                noviPravokutnik.Height = pocetak.Y - kraj.Y;
            }
            canvas.Children.Add(noviPravokutnik);

        }
        
        private void Olovka()
        {

        }


        private void itemElipsa_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            odabraniOblik = Oblik.Elipsa;
        }

        private void itemCrta_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            odabraniOblik = Oblik.Crta;
        }

        private void itemPravokutnik_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            odabraniOblik = Oblik.Pravokutnik;
        }

        private void btnOlovka_Click(object sender, RoutedEventArgs e)
        {
            odabranoPisalo = Pisalo.Olovka;
        }

        private void btnKist_Click(object sender, RoutedEventArgs e)
        {
            odabranoPisalo = Pisalo.Kist;
        }

        private void btnGumica_Click(object sender, RoutedEventArgs e)
        {

        }

        private void itemPath_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
